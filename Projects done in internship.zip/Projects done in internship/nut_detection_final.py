import os
import cv2
from datetime import datetime
import psycopg2
from ultralytics import YOLO

# Initialize variables
frame_no = 0
wrong_count = 0
input_name = '/home/docketrun/Desktop/final_nut_detection/yolov9/testing_small.mp4'
video_type_given = 'mp4'

# Set up database connection
conn = psycopg2.connect(
    dbname="docketrundb",
    user="docketrun",
    password="docketrun",
    host="localhost",
    port="5432",
)
cursor = conn.cursor()

# Create the Nut_Missing table if it does not exist
cursor.execute("""
    CREATE TABLE IF NOT EXISTS Nut_Missing4 (
        id SERIAL PRIMARY KEY,
        video_name VARCHAR(255),
        timestamp TIMESTAMP
    );
""")

conn.commit()

# Setup YOLO trained model
model = YOLO('/home/docketrun/Desktop/final_nut_detection/yolov9/yolov9_custom.pt')
results = model.predict(input_name, stream=True, conf=0.75, iou=0.80, line_width=2)
video = cv2.VideoCapture(input_name)
fps = video.get(cv2.CAP_PROP_FPS)

# Create directory to save images
output_directory = "nut_missing_images_9frames_each"
os.makedirs(output_directory, exist_ok=True)

# Function to resize frame
def resize_frame(frame, scale_percent=40):
    width = int(frame.shape[1] * scale_percent / 100)
    height = int(frame.shape[0] * scale_percent / 100)
    return cv2.resize(frame, (width, height), interpolation=cv2.INTER_AREA)

# Loop through the video frames
for result in results:
    frame_no += 1
    ret, frame = video.read()  

    # Check for nut missing
    if len(result.boxes.cls) == 1 and result.boxes.cls[0].item() == 0:
        wrong_count += 1
        timestamp = datetime.now()
        print("Nut detected")
        
        aa = result.boxes.xyxy[0][0].item()
        bb = result.boxes.xyxy[0][1].item()
        cc = result.boxes.xyxy[0][2].item()
        dd = result.boxes.xyxy[0][3].item()
     
    else:
        wrong_count = 0

    # To store every ninth consecutive frame of nut missing, store timestamp
    if wrong_count % 9 == 0 and wrong_count > 0:
        print("Nut missing detected - Timestamp:", frame_no / fps)
        timestamp = datetime.now()
        print("count:", wrong_count)
        
        # Store timestamp in PostgreSQL
        cursor.execute("INSERT INTO Nut_Missing4 (video_name, timestamp) VALUES (%s, %s);", (input_name, timestamp))
        conn.commit()
        # Locally store the image 
        image_name = os.path.join(output_directory, f"nut_missing_{frame_no}.jpg")
        cv2.imwrite(image_name, frame)

    # Resize frame
    resized_frame = resize_frame(frame)
    if len(result.boxes.cls) != 0:
        aa = result.boxes.xyxy[0][0].item()
        aa = aa * 0.4
        bb = result.boxes.xyxy[0][1].item()
        bb = bb * 0.4
        cc = result.boxes.xyxy[0][2].item()
        cc = cc * 0.4
        dd = result.boxes.xyxy[0][3].item()
        dd = dd * 0.4
        cv2.rectangle(resized_frame, (int(aa), int(bb)), (int(cc), int(dd)), (0, 0, 255), 2)
        cv2.putText(resized_frame, f"{'Nut Missing'}", (int(aa), int(bb) - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.75, (0, 0, 255), 2)
        cv2.rectangle(frame, (int(aa), int(bb)), (int(cc), int(dd)), (0, 0, 255), 2)
        cv2.putText(frame, f"{'Nut Missing'}", (int(aa), int(bb) - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.75, (0, 0, 255), 2)
    
    cv2.imshow("Resized Video", frame)
    cv2.imshow("Resized Video", resized_frame)
    
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Close database connection
cursor.close()
conn.close()

# Release video capture
video.release()
cv2.destroyAllWindows()
