import os
import cv2
from datetime import datetime
import psycopg2
from ultralytics import YOLO
from collections import defaultdict
import supervision as sv

# Set environment variable to resolve KMP_DUPLICATE_LIB_OK issue
os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'

# Set up database connection
conn = psycopg2.connect(
   dbname="docketrundb",
    user="docketrun",
    password="docketrun",
    host="localhost",
    port="5432",
)
cursor = conn.cursor()

# Create a table to store wheel crossing timestamps if not exists
cursor.execute("""
    CREATE TABLE IF NOT EXISTS Wheel_Crossing (
        id SERIAL PRIMARY KEY,
        video_name VARCHAR(255),
        timestamp TIMESTAMP,
        wheels_count INT
    );
""")
conn.commit()

# Initialize variables for wheel counting
model_wheels = YOLO('/home/docketrun/Desktop/final_wheel_count/yolov8_wheels.pt')
cap = cv2.VideoCapture("/home/docketrun/Desktop/final_nut_detection/yolov9/testing_small.mp4")

# Define the line coordinates
START = sv.Point(2050, 865)
END = sv.Point(2058, 1525)

# Store the track history
track_history = defaultdict(lambda: [])

# Create a dictionary to keep track of objects that have crossed the line
crossed_objects_sideline = {}

# Initialize count of wheels passing the line
count_wheels = 0

# Create directory to save images
output_directory = "wheel_crossing_images"
os.makedirs(output_directory, exist_ok=True)

# Set the desired width and height for the displayed video
display_width = 1280
display_height = 720

# Open a video sink for the output video
video_info = sv.VideoInfo.from_video_path("/home/docketrun/Desktop/final_nut_detection/yolov9/testing_small.mp4")
with sv.VideoSink("final_counting_output.mp4", video_info) as sink:

    # Loop through the video frames
    while cap.isOpened():
        success, frame = cap.read()

        if success:
            # Run YOLOv8 tracking on the frame, persisting tracks between frames
            results = model_wheels.track(frame, classes=[0], persist=True, save=True, line_width=3, conf=0.5, iou=0.7, tracker="bytetrack.yaml")

            # Get the boxes and track IDs
            boxes = results[0].boxes.xywh.cpu()
            track_ids = results[0].boxes.id.int().cpu().tolist()

            # Visualize the results on the frame
            annotated_frame = frame.copy()  # Create a copy of the frame for annotations

            # Plot the tracks and count objects crossing the line
            for box, track_id in zip(boxes, track_ids):
                x, y, w, h = box
                track = track_history[track_id]
                track.append((float(x), float(y)))  # x, y center point
                if len(track) > 20:  # retain 20 tracks for 20 frames
                    track.pop(0)

                # Check if the object crosses the line vertically
                if START.y < y < END.y and abs(x - START.x) < 5:  # Assuming objects cross vertically
                    if track_id not in crossed_objects_sideline:
                        crossed_objects_sideline[track_id] = True
                        count_wheels += 1  # Increment count when an object crosses the line
                        print("Wheel crossed the line. Current count:", count_wheels)

                        # Store wheel crossing timestamp and count in PostgreSQL
                        timestamp_wheels = datetime.now()
                        cursor.execute("INSERT INTO Wheel_Crossing (video_name, timestamp, wheels_count) VALUES (%s, %s, %s);",
                                       ("testing_srew.mp4", timestamp_wheels, count_wheels))
                        conn.commit()

                        # Save the frame
                        image_name = os.path.join(output_directory, f"wheel_crossing_{count_wheels}.jpg")
                        cv2.imwrite(image_name, frame)

                # Draw bounding box and label with resized font
                label = f"Wheel {track_id}"  # Example label
                cv2.rectangle(annotated_frame, (int(x - w / 2), int(y - h / 2)), (int(x + w / 2), int(y + h / 2)), (0, 0, 255), 2)  # Change color to red
                cv2.putText(annotated_frame, label, (int(x - w / 2), int(y - h / 2)), cv2.FONT_HERSHEY_SIMPLEX, 1.87, (0, 0, 255), 3)

            # Draw the line on the frame
            cv2.line(annotated_frame, (START.x, START.y), (END.x, END.y), (0, 255, 0), 2)

            # Write the count of objects passing the line on each frame
            count_text = f"Count of Wheels crossing the line: {count_wheels}"
            cv2.putText(annotated_frame, count_text, (10, 90), cv2.FONT_HERSHEY_SIMPLEX, 3, (0, 255, 0), 4)  # Adjust font size here

            # Resize the frame for display
            resized_frame = cv2.resize(annotated_frame, (display_width, display_height))

            # Write the frame with annotations to the output video
            sink.write_frame(resized_frame)
            
            # Display the annotated frame in real-time using OpenCV
            cv2.imshow('Frame', resized_frame)
            
            # Check if the user pressed 'q' to exit
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

        else:
            break

# Close database connection
cursor.close()
conn.close()

# Release video capture
cap.release()

# Close OpenCV windows
cv2.destroyAllWindows()
