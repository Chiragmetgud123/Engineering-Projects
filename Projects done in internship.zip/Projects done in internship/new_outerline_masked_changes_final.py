from ultralytics import YOLO
import cv2
import numpy as np

def main():
    # Load the YOLO model
    model = YOLO("C:/Users/chira/anaconda3/envs/yolov8_segmentation/yolov8_seg_EP.pt")

    # Open the input video
    cap = cv2.VideoCapture("C:/Users/chira/anaconda3/envs/Electrical_panel_segementation/new_videos_seg (4).mp4")
    if not cap.isOpened():
        print("Error: Cannot open video file.")
        return

    # Desired output resolution (for example, 1280x720)
    output_width = 1280
    output_height = 720

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        # Use the model to make predictions on the current frame
        results = model.predict(
            source=frame,
            show_conf=False,
            show_labels=False,
            show=False,
            conf=0.5,
            line_width=2
        )

        # Get the processed frame with segmentation masks
        processed_frame = results[0].orig_img if len(results) > 0 else frame

        if len(results) > 0 and results[0].masks is not None:
            masks = results[0].masks.data.cpu().numpy()
            colored_mask = np.zeros_like(processed_frame)

            # Define different colors for the masks
            colors = [
                [255, 0, 0],  # Red
                [0, 255, 0],  # Green
                [0, 0, 255],  # Blue
                [255, 255, 0],  # Cyan
                [255, 0, 255],  # Magenta
                [0, 255, 255],  # Yellow
                [128, 0, 0],  # Maroon
                [0, 128, 0],  # Olive
                [0, 0, 128],  # Navy
                [128, 128, 0],  # Purple
                [0, 128, 128],  # Teal
                [128, 0, 128],  # Fuchsia
                [192, 192, 192],  # Silver
                [128, 128, 128],  # Gray
                [0, 0, 0]  # Black
            ]

            for i, mask in enumerate(masks):
                color = colors[i % len(colors)]  # Cycle through colors
                mask_resized = cv2.resize(mask.astype(np.uint8), (processed_frame.shape[1], processed_frame.shape[0]))
                mask_resized = mask_resized.astype(bool)
                colored_mask[mask_resized] = color

                # Calculate contours of the mask
                contours, _ = cv2.findContours(mask_resized.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
                for contour in contours:
                    if contour.size > 0:
                        # Draw the contour outlines instead of bounding boxes
                        cv2.drawContours(processed_frame, [contour], 0, color, 2)

            # Blend the colored masks with the original frame
            processed_frame = cv2.addWeighted(processed_frame, 1, colored_mask, 0.5, 0)

        # Resize the processed frame to the desired output resolution
        resized_frame = cv2.resize(processed_frame, (output_width, output_height))

        # Display the resized frame
        cv2.imshow('Resized Output', resized_frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    # Release resources
    cap.release()
    cv2.destroyAllWindows()

if __name__== '__main__':
    main()
